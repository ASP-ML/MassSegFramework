import pandas as pd
from yolo_config import Config
from yolo_file_manager import FileManager
import os
import numpy as np
import matplotlib.pyplot as plt

metrics_names = [
    'metrics/mAP50(B)',
    'metrics/precision(B)',
    'metrics/recall(B)',
]

class MetricsAggregator():
    
    def __init__(self, file_manager:FileManager):
        self.file_manager = file_manager
        self.metrics = pd.DataFrame(columns=metrics_names)
        self.metrics.index.name = 'threshold'
        self.metrics_by_threshold = {
            t:pd.DataFrame(columns=metrics_names) for t in Config.THRESHOLDS
        }
        self.std = pd.DataFrame(columns=metrics_names)
        self.std.index.name = 'threshold'
        self.std_by_threshold = {
            t:pd.DataFrame(columns=metrics_names) for t in Config.THRESHOLDS
        }
    
    def add_metrics(self, threshold, valid_metrics, model_size):
        threshold_metrics = self.metrics_by_threshold[threshold]
        fold_name = self.file_manager.get_fold_name()
        threshold_metrics.loc[fold_name] = pd.Series(valid_metrics) 

        fold_path_name = self.file_manager.get_validation_project(threshold)
        fold_metrics_path = os.path.join(fold_path_name, f'metrics_{threshold}.csv')
        fold_metrics_df = pd.DataFrame([valid_metrics], index=[fold_name])
        fold_metrics_df.to_csv(fold_metrics_path)

        all_metrics_path = os.path.join(Config.RUNS_DIR, Config.DATASET, model_size, f'metrics_{threshold}.csv')
        threshold_metrics.to_csv(all_metrics_path)
        
    def finish_validation(self):
        for threshold in Config.THRESHOLDS:
            threshold_metrics = self.metrics_by_threshold[threshold]
            all_metrics_path = self.file_manager.get_all_metrics_path(threshold)
            threshold_metrics.to_csv(all_metrics_path)
            mean_metrics = threshold_metrics.mean()
            std_metrics = threshold_metrics.std()
            self.metrics.loc[threshold] = mean_metrics
            self.std.loc[threshold] = std_metrics
 
    def save_metrics(self):
        metrics_path = self.file_manager.get_metrics_path()
        self.metrics.to_csv(metrics_path)
        std_path = self.file_manager.get_std_path()
        self.std.to_csv(std_path)
