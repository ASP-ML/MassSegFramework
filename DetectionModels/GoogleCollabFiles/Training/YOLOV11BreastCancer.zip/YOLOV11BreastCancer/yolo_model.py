from ultralytics import YOLO
from yolo_config import Config
from yolo_file_manager import FileManager

# Add resume = true y en el model = YOLO (path del ultimo weight guardado)

class YoloModel:
    # Function to initialize the model
    def __init__(self, file_manager:FileManager):
        self.file_manager = file_manager
        pass
    
    # Function to train the model
    def train(self, resume = False, resume_weights = None):
        yaml_path = self.file_manager.get_yaml_path()
        project = self.file_manager.get_train_project()
        weights = resume_weights if resume else self.file_manager.get_pretrained_weights()

        print("Loading Model: ", weights)
        print("Resume Training on YAML: ", yaml_path) if resume else print("Training on YAML: ", yaml_path)
        model = YOLO(weights)

        model.train(
            data = yaml_path,
            project = project,
            name = 'train',
            imgsz = Config.IMG_SIZE,
            epochs = Config.EPOCHS,
            batch = Config.BATCH_SIZE,
            device = Config.DEVICE,
            patience = Config.PATIENCE,
            save_period = Config.SAVE_PERIOD,
            seed = Config.SEED,
            optimizer = 'Adam',
            lr0 = Config.HYP[Config.DATASET]['lr0'],
            lrf = Config.HYP[Config.DATASET]['lrf'],
            weight_decay = Config.HYP[Config.DATASET]['weight_decay'],
            box = Config.HYP[Config.DATASET]['box'],
            cls = Config.HYP[Config.DATASET]['cls'],
            scale = Config.HYP[Config.DATASET]['scale'],
            translate = Config.HYP[Config.DATASET]['translate'],
            mosaic = Config.HYP[Config.DATASET]['mosaic'],
            multi_scale = True,
            save = True,
            half = False,
            resume = resume # True to continue training from last checkpoint if training if interrupted
        )

    # Function to validate the model    
    def validate(self, threshold):
        yaml_path = self.file_manager.get_yaml_path()
        project = self.file_manager.get_validation_project(threshold)
        weights = self.file_manager.get_best_weights()

        print("Loading Model: ", weights)
        print("Validating on YAML: ", yaml_path)
        print("Threshold: ", threshold)
        best_model = YOLO(weights)

        metrics = best_model.val(
            data = yaml_path, 
            project = project,
            name = "val",
            imgsz = Config.IMG_SIZE,
            batch = Config.BATCH_SIZE,
            device = Config.DEVICE,
            split = 'val', 
            conf = threshold, 
            iou = 0.5,  # IOU threshold for NMS
            max_det = 10,  # Maximum detections per image
            half = False
        )
        
        return metrics.results_dict