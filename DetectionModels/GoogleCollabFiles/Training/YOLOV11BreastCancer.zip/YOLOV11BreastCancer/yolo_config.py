import torch

class Config:
    # Project settings
    ROOT = 'YOLOv11BreastCancer'
    # Eliminate comment depending of which dataset you want to use
    #DATASET = 'INbreast'
    DATASET = 'CBIS-DDSM' 
    RUNS_DIR = 'runs_test'
    DEVICE = 0
    LOCAL_ENV = False

    # Add the models you want to train in the [] separated with comas
    MODEL_SIZES = ['yolo11m.pt'] #'yolo11n.pt','yolo11s.pt'
    
    # Model settings
    EPOCHS = 200
    BATCH_SIZE = 16
    PATIENCE = 100
    SEED = 42
    SAVE_PERIOD = 25
    FOLDS = range(1,11)    
    THRESHOLDS = [0.001, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    IMG_SIZE = 640
    NUM_CLASSES = 1

    # Hyperparameters
    HYP = {
        'CBIS-DDSM': {
            'lr0': 0.000480736,
            'lrf': 0.157264,
            'weight_decay': 0.000318486,
            'box': 0.0473327,
            'cls': 0.794108,
            'scale': 0.311104,
            'translate': 0.0104767,
            'mosaic': 0.456487
        },
        'INbreast': {
            'lr0': 0.000675362,
            'lrf': 0.0582257,
            'weight_decay': 0.000142265,
            'box': 0.0917594,
            'cls': 1.31841,
            'scale': 0.257247,
            'translate': 0.0175932,
            'mosaic': 0.304154
        }
    }

    # Files
    YAML_FILE = 'data.yaml'
    METRICS_FILE = 'metrics.csv'
    STD_FILE = 'std.csv'
    
    # Function to make tests
    def set_local_settings():
        Config.MODEL_SIZES = ['yolo11n.pt']
        Config.EPOCHS = 1
        Config.BATCH_SIZE = 4
        Config.FOLDS = [1,2]
        Config.THRESHOLDS = [0.001, 0.1]
        Config.YAML_FILE = 'data.yaml'
        Config.LOCAL_ENV = True
    
    # Function to set GPU settings
    def set_gpu_settings():
        gpu_available = torch.cuda.is_available()
        Config.DEVICE = 0 if gpu_available else 'cpu'