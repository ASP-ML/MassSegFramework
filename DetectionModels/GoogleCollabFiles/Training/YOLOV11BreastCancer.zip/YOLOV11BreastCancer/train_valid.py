# %%
from yolo_config import Config
from yolo_file_manager import FileManager
from yolo_model import YoloModel
from yolo_metrics import MetricsAggregator, ROCAnalyzer
import time
import torch
import pandas as pd
from thop import profile
import os
# %%

if __name__ == '__main__':    
    Config.set_gpu_settings()
    performance_metrics = []

    # -----------------------
    # Model Training
    # -----------------------
    for model_size in Config.MODEL_SIZES:
        start_time = time.time()

        # Initialize components
        file_manager = FileManager(model_size)
        yolo_model = YoloModel(file_manager)
        metrics_aggregator = MetricsAggregator(file_manager)
        roc_analyzer = ROCAnalyzer(file_manager)

        # Clean up any previous runs
        file_manager.clean_model_runs()

        # Measure FLOPs and parameters
        input_tensor = torch.randn(1, 3, Config.IMG_SIZE, Config.IMG_SIZE).to(Config.DEVICE)
        flops, params = profile(yolo_model.model, inputs=(input_tensor,))
        print(f"Model: {model_size}")
        print(f"FLOPs: {flops/1e9:.2f}G, Parameters: {params/1e6:.2f}M")

        # Add model specs to metrics
        performance_metrics.append({
            'model': model_size,
            'phase': 'model_specs',
            'fold': 'N/A',
            'time_seconds': None,
            'memory_mb': None,
            'flops_g': flops/1e9,
            'params_m': params/1e6
        })

        # Training phase
        start_train_time = time.time()

        # -----------------------
        # K-fold Cross Validation
        # -----------------------
        for fold in Config.FOLDS:
            # Reset memory stats for this fold
            torch.cuda.reset_peak_memory_stats()  

            # Dataset setup
            file_manager.set_validation_setup(fold)

            # -----------------------
            # Training
            # -----------------------
            start_fold_time = time.time()
            yolo_model.train()
            end_fold_time = time.time()

            # Measure memory usage and time
            fold_time = end_fold_time - start_fold_time
            fold_memory = torch.cuda.max_memory_allocated() / 1e6  # MB
            print(f"Training time fold - {fold}: {fold_time:.2f} seconds")
            print(f"Memory used in fold - {fold}: {fold_memory:.2f} MB")

            # Record metrics
            performance_metrics.append({
                'model': model_size,
                'phase': 'training',
                'fold': fold,
                'time_seconds': fold_time,
                'memory_mb': fold_memory,
                'flops_g': None,
                'params_m': None
            })

            # Validation - Threshold Optimization
            all_predictions = []
            all_ground_truth = []

            # -----------------------
            # Validation
            # -----------------------
            for threshold in Config.THRESHOLDS:
                valid_metrics, predictions, ground_truth = yolo_model.validate(threshold)
                metrics_aggregator.add_metrics(threshold, valid_metrics)

                # Collect predictions and ground truth for ROC analysis
                if threshold == Config.THRESHOLDS[0]:  # Only need to collect once
                    all_predictions.extend(predictions)
                    all_ground_truth.extend(ground_truth)
            
            # Add fold predictions for ROC analysis
            roc_analyzer.add_fold_data(fold, all_predictions, all_ground_truth)
            # Clean up the weights after each fold
            file_manager.clean_weights()

        # Get the total training time
        total_train_time = time.time() - start_train_time
        print(f"Total training time for all folds: {total_train_time:.2f} seconds")

        # Aggregate Metrics
        metrics_aggregator.finish_validation()
        metrics_aggregator.save_metrics()

        # Generate ROC curve and find optimal threshold
        roc_analyzer.analyze_and_save()
        optimal_threshold = roc_analyzer.get_optimal_threshold()
        print(f"Optimal threshold based on ROC analysis: {optimal_threshold}")

        # Reset memory stats for testing
        torch.cuda.reset_peak_memory_stats()
        
        # -----------------------
        # Testing
        # -----------------------
        start_test_time = time.time()
        file_manager.set_testing_setup()
        yolo_model.train()
        end_test_time = time.time()

        # Get the total testing time and memory
        test_time = end_test_time - start_test_time
        test_memory = torch.cuda.max_memory_allocated() / 1e6  # MB
        print(f"Test time: {test_time:.2f} seconds")
        print(f"Memory used in test: {test_memory:.2f} MB")

        # Record test metrics
        performance_metrics.append({
            'model': model_size,
            'phase': 'testing',
            'fold': 'N/A',
            'time_seconds': test_time,
            'memory_mb': test_memory,
            'flops_g': None,
            'params_m': None
        })

        # Final test using optimal threshold
        print(f"Running final test with optimal threshold: {optimal_threshold}")
        test_metrics, predictions, ground_truth = yolo_model.validate(optimal_threshold)
        print(f"Final test metrics with optimal threshold: {test_metrics}")
    
    # Save performance metrics to CSV (corrected path)
    metrics_dir = os.path.join(Config.ROOT, "metrics")
    os.makedirs(metrics_dir, exist_ok=True)
    performance_path = os.path.join(metrics_dir, f'performance_metrics_{Config.DATASET}.csv')
    pd.DataFrame(performance_metrics).to_csv(performance_path, index=False)
    print(f"Performance metrics saved to {performance_path}")
